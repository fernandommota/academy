/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ufms;

/**
 *
 * @author fernandommota
 */
public class Aluno extends Participante{
    private int rga;
    private int idade;
    private String curso;

    public Aluno(Evento evento) {
        super(evento);
    }
        
    public void listaEventos() {
        for(int i=0; i < evento.size(); i++){
            System.out.println(evento.get(i).getNome());
        }
    }

    
    public void addEvento(Evento evento) {
        this.evento.add(evento);
    }

    public void removeEvento(Evento evento) {
        this.evento.remove(evento);
    }
    
    
}
