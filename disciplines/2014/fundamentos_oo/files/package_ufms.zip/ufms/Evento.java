/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ufms;
import java.util.Date;
import java.util.ArrayList;
/**
 *
 * @author fernandommota
 */
public class Evento {
    private String nome;
    private Date dataInicio;
    private Date dataFim;
    private String local;
    private String descricao;
    private ArrayList<Palestra> programacao;
    private String atividades;
    private Administrador administrador;
    private ArrayList<Participante> participante;

    public Evento(Administrador administrador, Palestra palestra){
        participante= new ArrayList< Participante >();
        programacao= new ArrayList< Palestra >();
        
        this.administrador=administrador;
        this.programacao.add(palestra);
    }
    
    public void listaParticipantes(){
        for(int i=0; i < participante.size(); i++){
            System.out.println(participante.get(i).getNome());
        }
    }
    public void addParticipante(Participante participante){
        this.participante.add(participante);
    }
    
    public void removeParticipante(Participante participante){
        this.participante.remove(participante);
    }
    
    public void addPalestra(Palestra palestra){
        this.programacao.add(palestra);
    }
    
    public void removePalestra(Palestra palestra){
        this.programacao.remove(palestra);
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }

    public Date getDataFim() {
        return dataFim;
    }

    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Palestra getProgramacao(int index) {
        return programacao.get(index);
    }

    public String getAtividades() {
        return atividades;
    }

    public void setAtividades(String atividades) {
        this.atividades = atividades;
    }

    public Administrador getAdministrador() {
        return administrador;
    }

    public void setAdministrador(Administrador administrador) {
        this.administrador = administrador;
    }

    public Participante getParticipante(int index) {
        return participante.get(index);
    }

    public void setParticipante(Participante participante) {
        this.participante.add(participante);
    }
   
    
    
}
