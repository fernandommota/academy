/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ufms;
import java.util.Date;
/**
 *
 * @author fernandommota
 */
public class Palestra {
    private Pessoa palestrante;
    private String tema;
    private String titulo;
    private int duracao;
    private Date data;

    public Palestra(Pessoa palestrante){
        this.palestrante=palestrante;
    } 
    public Pessoa getPalestrante() {
        return palestrante;
    }

    public void setPalestrante(Pessoa palestrante) {
        this.palestrante = palestrante;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }
    
    
}
