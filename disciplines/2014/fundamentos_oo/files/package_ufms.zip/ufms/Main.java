/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ufms;

/**
 *
 * @author fernandommota
 */
public class Main {
    public static void main(String args[]){
        //cria administrador
        Administrador admin= new Administrador();
        admin.setNome("Fernando");
        
        //cria a palestra XPTO
        Palestra palestra= new Palestra(admin);
        palestra.setTitulo("XPTO");
        
        //cria evento A
        Evento evtA= new Evento(admin, palestra);
        evtA.setNome("Evento A");
        
        //cria participante Carlos
        Aluno carlos= new Aluno(evtA);
        carlos.setNome("Carlos");
        
        //cadstra carlos no evento A
        evtA.setParticipante(carlos);
        
        //imprime eventos de carlos
        carlos.listaEventos();
        
        //imprime participantes de Evento A
        evtA.listaParticipantes();
        

        
        
       
    }
}
