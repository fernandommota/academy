/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ufms;

/**
 *
 * @author fernandommota
 */
public class Pessoa {
    private int rg;
    private String cpf;
    private String nome;
    private String profissão;
    private String telefone;
    private String endereco;
    private String email;
    
    private void imprimirDadosPessoais(){
        System.out.println("RG: "+getRg());
        System.out.println("cpf: "+getCpf());
        System.out.println("nome: "+getNome());
        System.out.println("profissão: "+getProfissão());
        System.out.println("telefone: "+getTelefone());
        System.out.println("endereco: "+getEndereco());
        System.out.println("email: "+getEmail());
    }

    public int getRg() {
        return rg;
    }

    public void setRg(int rg) {
        this.rg = rg;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfissão() {
        return profissão;
    }

    public void setProfissão(String profissão) {
        this.profissão = profissão;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
}
