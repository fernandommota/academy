/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ufms;

/**
 *
 * @author fernandommota
 */
public class Administrador extends Pessoa{
    /*  este metodo ficou impossibilitado, pois
        necessita passar um administrador no construtor
    public Evento cadastraEvento(){
        Evento ev= new Evento();
        return ev;
    }
    */
    public void cadastraPessoas(Participante participante, Evento evento){
        evento.addParticipante(participante);
        participante.addEvento(evento);
    }
}
