/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ufms;
import java.util.ArrayList;
/**
 *
 * @author fernandommota
 */
public abstract class Participante extends Pessoa{
    public ArrayList<Evento> evento;
    
    public abstract void listaEventos();
    public abstract void addEvento(Evento evento);
    public abstract void removeEvento(Evento evento);
    
    public Participante(Evento evento){
        this.evento = new ArrayList< Evento >();
        this.evento.add(evento);
    }
}
