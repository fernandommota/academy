/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos_swing;

/**
 *
 * @author fernandommota
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LabelTest extends JFrame {

    private JLabel label1, label2, label3;

    public LabelTest() {   //construtor
        super("Testando JLabel");

        Container c = this.getContentPane();
        c.setLayout(new FlowLayout());

        label1 = new JLabel("Label com texto");
        label1.setToolTipText("Este é o label 1");
        c.add(label1);

        Icon seta = new ImageIcon("C:\\Users\\fernandommota\\Dropbox\\academy\\UFMS\\disciplinas\\FUNDAMENTOS EM ORIENTAÇÃO A OBJETOS\\labs\\LabsTOO2014\\src\\exemplos_swing\\back.png");
        label2 = new JLabel("Label com texto e ícone",
                seta,
                SwingConstants.LEFT);
        label2.setToolTipText("Este é o label 2");
        c.add(label2);
        label3 = new JLabel();
        label3.setText(
                "Label com ícone e texto na base");
        label3.setIcon(seta);
        label3.setHorizontalTextPosition(
                SwingConstants.CENTER);
        label3.setVerticalTextPosition(
                SwingConstants.BOTTOM);
        label3.setToolTipText("Este é o label 3");
        c.add(label3);

        this.setSize(250, 250);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public static void main(String[] args) {
        LabelTest app = new LabelTest();

    }
}
