/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lista2.dez;

/**
 *
 * @author fernandommota
 */
public class Animal {
    private int pernas=0;
    
    public Animal(){
        //codigo omitido
    }
    
    public  void caminha(){
        //codigo omitido
    }
    
    public  void come(){
        //codigo omitido
    }
}
