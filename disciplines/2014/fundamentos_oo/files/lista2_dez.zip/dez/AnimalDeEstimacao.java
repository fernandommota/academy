/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lista2.dez;

/**
 *
 * @author fernandommota
 */
public interface AnimalDeEstimacao {
    
    public String getNome();
    public void setNome(String nome);
    public void brinca();
}
