/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lista2.dez;

/**
 *
 * @author fernandommota
 */
public class Cachorro extends Animal implements AnimalDeEstimacao{
    private String nome;
    
    public Cachorro(){
        
    }
    
    public Cachorro(String nome){
        
    }

    public void brinca(){
        
    } 
    
    public void come(){
        
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
