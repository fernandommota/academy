/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package heranca;

/**
 *
 * @author fernandommota
 */
public class Cliente extends Pessoa{
    
    private Conta conta;

   
    public Cliente(Conta conta){
        conta.setLimite(1000.00);
        this.conta=conta;
    }

    public Conta getConta() {
        return conta;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }
    
    public void depositar(double valor){
        conta.setSaldo(valor);
    }
        
    public void sacar(double valor){
        conta.setSaldo(valor*-1);
    }    
    public void extrato(){
        double saldo=conta.getSaldo();
        System.out.println("\nExtrato\n"+
            "Agência: "+conta.getAgencia()+" - "+
            "Conta: "+conta.getNumero()+"\n"+
            "Cliente: "+getNome()+" - "+
            "limite: "+conta.getLimite()+"\n"+
            "Saldo: "+conta.getSaldo()+"\n\n");
    }   
}
