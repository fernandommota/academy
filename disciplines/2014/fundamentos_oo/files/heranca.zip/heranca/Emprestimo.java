/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package heranca;

/**
 *
 * @author fernandommota
 */
public abstract class Emprestimo {
    private Conta conta;
    private double valorEmprestado;
    private boolean ativo;
    
    public Emprestimo(){
        //System.out.println("Construtor classe empréstimo!");
    }
    public abstract void creditaEmprestimo(double valor);
    public abstract void debitarEmprestimo(double valor);
    
    public Conta getConta() {
        return conta;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }

    public double getValorEmprestado() {
        return valorEmprestado;
    }

    public void setValorEmprestado(double valor) {
        this.valorEmprestado = valor;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

}
