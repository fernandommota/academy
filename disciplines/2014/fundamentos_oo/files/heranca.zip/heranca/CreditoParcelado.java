/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package heranca;

/**
 *
 * @author fernandommota
 */
public class CreditoParcelado extends Emprestimo{
    
    public CreditoParcelado(Conta conta, double valor){
        setConta(conta);
        setValorEmprestado(valor);
        getConta().setSaldo(valor);
        setAtivo(true);
    }
    public void creditaEmprestimo(double valor) {
        getConta().setSaldo(valor);
        setValorEmprestado(getValorEmprestado()+valor);
    }

    public void debitarEmprestimo(double valor) {
        getConta().setSaldo(valor*-1);
        setValorEmprestado(getValorEmprestado()-valor);
        if(getValorEmprestado()<=0)
            setAtivo(false);
    }
    
}
