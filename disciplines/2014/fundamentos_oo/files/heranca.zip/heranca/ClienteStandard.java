/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package heranca;

/**
 *
 * @author fernandommota
 */
public class ClienteStandard extends Cliente{
    public ClienteStandard(Conta conta) {
        super(conta);          
    }   
    /*
    public void extrato(){
        System.out.println("Dentro da subclasse");
        super.extrato();
    }
    */
}
