/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package heranca;

/**
 *
 * @author fernandommota
 */
public class ClientePrime extends Cliente{
    private double limiteEspecial;

    public ClientePrime(Conta conta) {
        super(conta);
        setLimiteEspecial(500.00);
    }
    
    public void extrato(){
        double saldo=getConta().getSaldo();
        System.out.println("\nExtrato\n"+
            "Agência: "+getConta().getAgencia()+" - "+
            "Conta: "+getConta().getNumero()+"\n"+
            "Cliente: "+getNome()+" - "+
            "limite: "+getConta().getLimite()+"\n"+
            "limite Especial: "+getLimiteEspecial()+"\n"+
            "Saldo: "+getConta().getSaldo()+"\n\n");
    }
   
    public double getLimiteEspecial() {
        return limiteEspecial;
    }

    public void setLimiteEspecial(double limiteEspecial) {
        this.limiteEspecial = limiteEspecial;
    }
    
}
