/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package heranca;



/**
 *
 * @author fernandommota
 */
public class Main {
    public static void main(String args[]){
        //cadastro de conta 
        Conta novaConta= new Conta(110,7030,500.00);
        //cadastro de Conta Prime/Cliente Prime
        ClienteStandard mc= new ClienteStandard(novaConta);
        mc.setNome("Maria Clara");       
        mc.setCpf("543.752.355-98");
        mc.setRg(74853);
        mc.extrato();
        //deposito
        //mc.depositar(100.00);
        //mc.extrato();        
        //saque
        //mc.sacar(110.00);
        //mc.extrato();
        
        
        //cadastro de conta 
        novaConta= new Conta(110,8032,1000.0);
        //cadastro de Conta Prime/Cliente Prime
        ClientePrime ac= new ClientePrime(novaConta);
        ac.setNome("Antonio Carlos");       
        ac.setCpf("123.432.345-65");
        ac.setRg(176534);
        ac.extrato();
        
        //deposito
        //ac.depositar(500.00);
        //ac.extrato();        
        //saque
        //ac.sacar(250.00);
        //ac.extrato();
        
        
        CreditoParcelado cp= new CreditoParcelado(ac.getConta(), 400.00);
        ac.extrato();
        cp.debitarEmprestimo(200.00);
        ac.extrato();
    }
    
}
