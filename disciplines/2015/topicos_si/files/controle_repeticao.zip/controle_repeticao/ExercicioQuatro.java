/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicios.fixacao.controle_repeticao;

/**
 *
 * @author fernandommota
 */
import java.util.Scanner;
public class ExercicioQuatro {
    public ExercicioQuatro(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira X:");
        int x = sc.nextInt();
        int somatorio=0;
        System.out.println("Termo 1:"+x);
        for(int i=1; i < 30; i++){
           somatorio+=(2*Math.pow(x,2))/4;
           System.out.println("Termo "+(i+1)+":"+somatorio);
        }
        
    }
}
