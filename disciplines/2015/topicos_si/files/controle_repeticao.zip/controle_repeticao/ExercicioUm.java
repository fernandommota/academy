/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicios.fixacao.controle_repeticao;

/**
 *
 * @author fernandommota
 */
import java.util.Scanner;
public class ExercicioUm {
    public ExercicioUm(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira n:");
        int n = sc.nextInt();
        
        System.out.println("Insira o 1º valor:");
        double  maior= sc.nextDouble();
        double menor = maior;
        
        if(n>1){
            double aux;
            for(int i=1; i< n; i++){
                System.out.println("Insira o "+(i+1)+"º valor:");
                aux=sc.nextDouble();
                if(aux > maior)
                    maior=aux;
                else if(aux < menor)
                    menor=aux;
            }
        }
        
        System.out.println("Maior: "+maior);
        System.out.println("Menor: "+menor);
        
    }
}
