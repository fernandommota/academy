/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicios.fixacao.controle_repeticao;

/**
 *
 * @author fernandommota
 */
import java.util.Scanner;
public class ExercicioSeis {
    public ExercicioSeis(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira x:");
        int x = sc.nextInt();
        //[0,25] (25,50], (50,75], (75,100]
        
        if(x>=0 && x<=25)
             System.out.println("[0,25]");   
        else if(x>25 && x<=50)
            System.out.println("(25,50]");  
        else if(x>50 && x<=75)
            System.out.println("(50,75]"); 
        else if(x>75 && x<=100)
            System.out.println("(75,100]"); 
        else 
            System.out.println("Fora do intervalo!");
    }
}
