/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicios.fixacao.controle_repeticao;

/**
 *
 * @author fernandommota
 */
import java.util.Scanner;
public class ExercicioSete {
    public ExercicioSete(){
        Scanner sc = new Scanner(System.in);
        double notaUm;
        double notaDois;
        int opcao;
        do{
            do{
                System.out.println("Insira nota um:");
                notaUm = sc.nextDouble();
            }while(notaUm<0 || notaUm>10);
            do{
                System.out.println("Insira nota dois:");
                notaDois = sc.nextDouble();
            }while(notaDois<0 || notaDois>10);
            System.out.println("Média semestral: "+((notaUm+notaDois)/2));    
            System.out.println("Deseja realizar um novo cálculo:\n1-Sim\n2-Não");
            opcao = sc.nextInt();
        }while(opcao==1);
    }
}
