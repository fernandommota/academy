/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicios.fixacao.controle_repeticao;

/**
 *
 * @author fernandommota
 */
import java.util.Scanner;
public class ExercicioTres {
    public ExercicioTres(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira N:");
        int n = sc.nextInt();
        
        int termoAnterior=0;
        int termo=1;
        int aux;
        
        System.out.println("n0= "+termoAnterior);
        System.out.println("n1= "+termo);
        for(int i=2; i < n; i++){
            aux=termo;
            termo=termo+termoAnterior;
            termoAnterior=aux;
            
            System.out.println("n"+(i+1)+"= "+termo);
        }
        
    }
}
