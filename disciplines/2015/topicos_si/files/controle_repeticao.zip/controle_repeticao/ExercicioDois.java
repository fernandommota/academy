/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicios.fixacao.controle_repeticao;

/**
 *
 * @author fernandommota
 */
import java.util.Scanner;
public class ExercicioDois {
    public ExercicioDois(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira A:");
        int a = sc.nextInt();
        
        System.out.println("Insira B:");
        int  b= sc.nextInt();
       
        int aux=a;
        a=b;
        b=aux;
        
        System.out.println("A: "+a);
        System.out.println("B:"+b);
        
    }
}
