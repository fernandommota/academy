/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicios.fixacao.controle_repeticao;

import javax.swing.JOptionPane;

/**
 *
 * @author fernandommota
 */
public class Main {
    public static void main(String args[]){
        //ExercicioUm exercicioUm= new ExercicioUm();
        //ExercicioDois exercicioDois= new ExercicioDois();
        //ExercicioTres exercicioTres= new ExercicioTres();
        //ExercicioQuatro exercicioQuatro= new ExercicioQuatro();
        //ExercicioCinco exercicioCinco= new ExercicioCinco();
        //ExercicioSeis exercicioSeis= new ExercicioSeis();
        ExercicioSete exercicioSete= new ExercicioSete();
    }
    
}
