/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package exercicios.fixacao.controle_repeticao;

/**
 *
 * @author fernandommota
 */
import java.util.Scanner;
public class ExercicioCinco {
    public ExercicioCinco(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira x:");
        int x = sc.nextInt();
        int fatorial=x;
        for(int i=x-1; i >0; i--){
            System.out.println(fatorial+"*"+i);
           fatorial=fatorial*i;
           
        }
        System.out.println("Fatorial de "+x+" é:"+fatorial);
    }
}
